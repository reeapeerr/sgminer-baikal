#ifndef LBRY_H
#define LBRY_H

#include "miner.h"

extern void lbry_regenhash(struct work *work);

#endif
